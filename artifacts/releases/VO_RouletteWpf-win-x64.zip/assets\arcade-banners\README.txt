Place arcade banner images under:

assets/arcade-banners/source/OMG
assets/arcade-banners/source/VOOT
assets/arcade-banners/source/FORCE
assets/arcade-banners/source/VOINDEX

For OMG/FORCE/VOINDEX:
- one PNG per character.

For VOOT:
- one PNG per character for DNA and RNA each.
- file names must start with "DNA_" or "RNA_".
- accepted examples:
  DNA_RAIDEN.png
  DNA_1080SP.png
  RNA_RAIDEN.png
  RNA_BALBADOS.png

Character name matching is flexible (raw Japanese name, alias, normalized name).
